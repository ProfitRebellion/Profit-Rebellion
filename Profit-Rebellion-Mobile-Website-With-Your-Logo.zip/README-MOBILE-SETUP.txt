PROFIT REBELLION — MOBILE-FRIENDLY WEBSITE / PWA

Upload these files together to the ROOT of your GitHub repository:
- index.html
- profit-rebellion-logo.png
- manifest.webmanifest
- service-worker.js

Commit the changes, then wait for GitHub Pages to deploy.

iPhone: Open the published website in Safari > Share > Add to Home Screen > Add.
Android: Open the published website in Chrome > menu > Install app or Add to Home screen.

GitHub Pages must be served over HTTPS for service-worker/PWA features. This package does not publish itself to GitHub.
